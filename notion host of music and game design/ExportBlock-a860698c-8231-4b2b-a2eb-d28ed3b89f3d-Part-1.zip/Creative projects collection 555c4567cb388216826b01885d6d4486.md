# Creative projects collection

<aside>

*“It adds a question: does this aesthetic sense also exist in the lower forms? Why is it aesthetic? All kinds of interesting questions which the science knowledge only adds to the excitement, the mystery and the awe of a flower. It only adds. I don’t understand how it subtracts.” - Richard Feynman.*

</aside>

---

![](https://media2.giphy.com/media/v1.Y2lkPTc5NDFmZGM2bDdma2Z6a2hycWZzdjA2bXY4ZHpqb2cyeTloMHBzdzluYzY1ZTBuaiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/fTz2gJRh37GpDaiiyD/giphy.gif)

### To do list

---

- [x]  git commit 1.1.2
- [ ]  formalise documentation
- [ ]  track mana expenditure models
- [x]  format game design documents
- [x]  Merge collections of alice in tir na ceol
- [ ]  

---

---

---

### *Currently Reading ☕*

![the-fifth-season-12.jpg](Creative%20projects%20collection/the-fifth-season-12.jpg)

### *Currently listening*

![the-fifth-season-12.jpg](https://media0.giphy.com/media/v1.Y2lkPTc5NDFmZGM2aTNhc2diM2lnYmQ4OHk2MnNrbG83MmFyMGFrbDdiNThjYnRlMW40cCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/WUxmd1cxJSISBwvvgn/giphy.gif)

### Music projects

[Courses](Creative%20projects%20collection/Courses%20f96c4567cb3882019126010763c7a3bd.csv)

---

---

### Game design projects

[Courses (1)](Creative%20projects%20collection/Courses%20(1)%20377c4567cb3880768a3bcea2e4d8860b.csv)