# Welcome to my notion page

Status: Completed
Submissions: Submission 1 (https://app.notion.com/p/Submission-1-60dc4567cb3882e09a83812e5d8284f8?pvs=21), Submission 2 (https://app.notion.com/p/Submission-2-391c4567cb3883e49a6881f8a3b2ab0a?pvs=21)
Year: 2026