# All Game design projects

Status: Ongoing
Submissions: Submission 4 (https://app.notion.com/p/Submission-4-884c4567cb3883c49b8201814ff3dfee?pvs=21)
Year: 2026

# fantasy TTRPG concept - Blue divinity

Blue divinity, or BD - is an amalgamation of ideas from throughout my years, stretching back to when I was 8 years old! From my fellow D&D - obsessed peers, to game designers I’ve followed, to my own long and winding history of reading and writing fantasy novels. 

### where it all started - 2024

[Tome of lost legends - nottescorice](https://homebrewery.naturalcrit.com/share/4KVfmOdeYWeP)

[the seer - nottescorice](https://homebrewery.naturalcrit.com/share/7PFrUR4aLpPl)

These are the earliest documents I can find with comprehensive, detailed notes. Anything before that is a jumble of ideas. Here, I finally had the confidence to create D&D inspired, richly formatted documentation. The HTML was a bit wonky, the game design elements questionable, but it was a start.

### where it is - 2025

[blue divinity v1 - twinachino](https://homebrewery.naturalcrit.com/share/LihK4tdnt4lp)

This is the latest formatted document. Since then, i’ve moved to the app chronicler - for better offline work and Github support - allowing me to better track my progress. I’ve decided to move towards professional workflows to latter support my copyright.

### where it’s going - 2026

Since then, I’ve met people of all kinds - those obsessed with the mechanics of the game. Those in love with graphic design, 3d Modelling, music composition, storywriting, etc. Whilst the project is primarily piloted by me, it will become a **team effort** born out of passion for fantasy.

Now, i’ve decided to host the newest versions here on Chronicler. You can view the raw markdown here on github: 

[](https://github.com/twinachinoo/BLUE_DIVINITY/tree/main)

### what’s the point?

This game, along with it’s many inspirations, previous iterations, and endless, sprawling worldbuilding threads, is the core of my creative expression. Game design aligns my passions for programming, music, visual art, writing, and so much more. It’s a core crystallisation of my creative ability.