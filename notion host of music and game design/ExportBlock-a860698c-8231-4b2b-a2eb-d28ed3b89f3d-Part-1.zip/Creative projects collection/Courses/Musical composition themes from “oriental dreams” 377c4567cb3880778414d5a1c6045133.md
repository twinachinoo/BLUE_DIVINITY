# Musical composition: themes from “oriental dreams”

Status: Ongoing
Submissions: Submission 3 (https://app.notion.com/p/Submission-3-158c4567cb38822b91d701d6ff28c128?pvs=21)
Year: 2024

# what is oriental dreams?

oriental dreams is the name of the D&D Campaign I was going to run two years ago. I decided to make some music for it, before I was wrapped up in academics and forgot about it…until very recently. 

oriental dreams, as a campaign, and as the music that accompanies it, is a campaign set in a faux-ancient china. It takes historical locations, architecture, culture, music, and many other aspects of ancient china, and gives them a magical, fantastical flair fit for a roleplaying game. The music I wanted to write was similar, drawing inspirations from modern chinese wuxia-style music, blending traditional elements into a modern composing style.

[oriental dreams 0606.pdf](Musical%20composition%20themes%20from%20%E2%80%9Coriental%20dreams%E2%80%9D/oriental_dreams_0606.pdf)

below attached is the midi render. headphones reccomended:

[oriental dreams 0606.mp3](Musical%20composition%20themes%20from%20%E2%80%9Coriental%20dreams%E2%80%9D/oriental_dreams_0606.mp3)

### the breakthrough

Oriental dreams was my first attempt at utilising the full orchestra. I experimented with warm brass, fluttering woodwinds, and traditional chinese percussion. before this, many of my pieces were simple and plain, meant only for the comfort of the piano or the Viola. This was the first time I stepped out from my comfort zone, and though the piece has some hiccups, I was so relieved to see it turn out alright. It was a definite green light for me that I should write for orchestra from now on.

### the Link to [All Game design projects](../Courses%20(1)/All%20Game%20design%20projects%20380c4567cb38836ab68981b20570829f.md)

oriental dreams, though a long gone campaign, continues to inspire my game design efforts to this day. I am already planning multiple pieces of music to go alongside my Game design projects. Without one or the other, these two would not have existed as standalones. It’s precisely that nature of connections and networks that generates so much inspiration for me.