# Welcome to my notion page :D

Status: Ongoing
Year: click here!

Thank you for reading through my Application letter! I am deeply, deeply grateful for your time. I will not hold you any longer here.

# for music

For music, the pieces I would like to present are:

[Musical composition: “Alice in Tir na Ceol”](Musical%20composition%20%E2%80%9CAlice%20in%20Tir%20na%20Ceol%E2%80%9D%20377c4567cb3880909fb0c6e26b89970d.md) 

[musical composition: “An introduction”](musical%20composition%20%E2%80%9CAn%20introduction%E2%80%9D%20795c4567cb38828988d4814d37753138.md) 

[Musical composition: themes from “oriental dreams”](Musical%20composition%20themes%20from%20%E2%80%9Coriental%20dreams%E2%80%9D%20377c4567cb3880778414d5a1c6045133.md) 

Each composed at different times of my past, for different reasons, different people, and ultimately, led to different experiments with music, stretching the limits of my comfort zone outside of instruments I already play.

You may also peruse the projects at any time by exiting this page and clicking on the appropriate project blocks on the frontpage.

### documentation and analysis

Each project will have its detailed documentation about why I composed it, the themes and story behind the music, and more. Feel free to read these in your free time.

### That’s it?

I’ve composed much more music in my life, but i feel these are the most recent, best works by me. They best show the style of music I love to play and write.

### the best two

If the rule of “two pieces of supporting evidence” strictly applies, please look at [Musical composition: “Alice in Tir na Ceol”](Musical%20composition%20%E2%80%9CAlice%20in%20Tir%20na%20Ceol%E2%80%9D%20377c4567cb3880909fb0c6e26b89970d.md) and [musical composition: “An introduction”](musical%20composition%20%E2%80%9CAn%20introduction%E2%80%9D%20795c4567cb38828988d4814d37753138.md) first, as they are the most recent and most well documented and composed.

# for game design

Whilst I am here primarily presenting my music as my arts scholarship material, I want to say that game design is another *huge, huge* part of me I cannot afford to not show. 

I won’t keep you here for too long, feel free to take a look at some of the projects I’ve worked on over the years. Each one is a comprehensive, multi paged document, richly formatted and illustrated with images, made as standalone projects with real history, playtesting, and even deployment onto the tabletop itself!

## concerning copyright

Do note that all of the music and game projects are protected under european copyright Law, since that was where the majority of the content was created, had recorded commits, and I intend to transform into an IP later.