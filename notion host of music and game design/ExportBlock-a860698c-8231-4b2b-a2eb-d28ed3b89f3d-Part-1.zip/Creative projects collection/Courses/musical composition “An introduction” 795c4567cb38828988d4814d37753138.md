# musical composition: “An introduction”

Status: Ongoing
Submissions: Submission 1 (https://app.notion.com/p/Submission-1-60dc4567cb3882e09a83812e5d8284f8?pvs=21)
Year: 2026

# What is “an introduction”?

Sometimes you just can’t think of a name for a piece of music, so instead of trying to force a theme on it, i’ve decided to let the music speak for itself.My most recent composition. quite literally an introductory part to series of through composed soundscapes. Composed with musescore. 

[0506 v1.pdf](musical%20composition%20%E2%80%9CAn%20introduction%E2%80%9D/0506_v1.pdf)

Below attached is an audio render. headphones reccomended. The nature of DAW software is the lack of subtlety of a human musican, but it’s the best I can do.

[0506 v1.mp3](musical%20composition%20%E2%80%9CAn%20introduction%E2%80%9D/0506_v1.mp3)

### The backstory

This music spawned out of a sudden fire of musical vigor. I was tasked by the conductor to write for the ochestra, and with that, a passionate flurry of notes landed on the page. Sometimes, music is just that for me - an in-the-moment, burst of inspiration. Where I felt words were not enough to express the soul burning emotion of passion. 

### the point?

Here’s where I truly found my joy for composing. In truth, this music had no point - no story to attach to it. It was music, for the sake of music. It lacked a title, and the music expressed everything that I wished to express. I embraced the transition from being just a musician - only playing the instrument, to a composer. And that’s where I stand now.

### the instruments

I wanted to challenge myself by writing for an instrument family unfamiliar to me - the brass, by giving the streotypically loud trumpet - the soft, mellow lead. The trumpet players in my orchestra have a masterful control over their texture and volume. Playing into the strengths of the players is vital for composition that actually makes it out onto the stage.

### The orchestra

This piece is soon to be performed by the CYO - the cork youth orchestra, for a live recording. The Conductor hsa already approved the go-ahead for the live rehearsal.

###