# Musical composition: “Alice in Tir na Ceol”

Status: Ongoing
Submissions: Submission 2 (https://app.notion.com/p/Submission-2-391c4567cb3883e49a6881f8a3b2ab0a?pvs=21)
Year: 2025

# what is Alice in Tir na Ceol?

Alice in Tir na Ceol is a name originating from another piece we played years ago. The last three words are irish - which mean “Land of music”. It’s a collection of pieces drawing inspiration from the story of Aliec in wonderland. 

[alice in tir na ceol 0606.pdf](Musical%20composition%20%E2%80%9CAlice%20in%20Tir%20na%20Ceol%E2%80%9D/alice_in_tir_na_ceol_0606.pdf)

below attached is the midi render. headphones reccomended:

[alice in tir na ceol 0606.mp3](Musical%20composition%20%E2%80%9CAlice%20in%20Tir%20na%20Ceol%E2%80%9D/alice_in_tir_na_ceol_0606.mp3)

### the backstory

Alice in Tir na ceol was originally a piece that I never really liked. I had lengthy discussions with the conductor and other musicians, and through sleepless nights and endless fustrated hours, I have pieced together a collection of pieces I felt I was delighted with.

### the Theming

Alice in Tir na Ceol is currently broken up into three parts: Wonderland, Dreaming, and Mellow. It’s through-composed, meant to suit a narrator or an animated short. 

#### Wonderland

The piece wonders with “wonderland” - a poignant parallel to the source of inspiration. Here, I invisioned the literal act of flipping through the first few pages of the storybook. 

The celeste is an instrument we’re all too familiar with fantasy and magical settings. Here, i have it set in a repeating line, mimicking the motion of flipping pages, creating an immidate sense of mystery.

As the delicate strings slowly layer in with their harmonics, they move through modal harmonies. The music captures a feeling of letting yourself loose into immersion - crossing into the realm of words on the page, but you haven’t stepped through the gateway yet.

#### dreaming

Dreaming is where alice soars through the clouds and enters the land of music, and begins her imaginative dream. The solo violin leads the transition from pure strings into a lush, almost impressionistic soundscape of the harp and celesta. They create a shimmering, moving texture, dancing around the strings.

 With sparse accents from other instruments, the sounds ebb and flow through swells of dynamics, it’s meant to feel weightless, fluid, and of course, dreamlike, like you’ve soared into the clouds and left the ground. eventually, your ascent slows, and we transition into…

#### mellow

Mellow…what, exactly? that question is left for the listener to interpret. The strings shift to sul tasto, accomapnied by soft, muted woodwinds and brass to fill the harmonic soundscape. The music here moves through non functional harmony, shifting from different chords with no particular pattern or progression. It’s less “dreamy” or “soaring”, more like you’ve found a cloud to stand on for now.

### what’s next?

This piece will continue to be through commposed as more inspiration comes to mind. Currently, I have sections like through the looking glass, the lady of pain, thorns and roses, shadow of the moon, planned. The music here is genuinely unknown, and perhaps inspiration will strike again one day.